//
//  SourcesViewController.h
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AUIPopupWindow.h"
#import "AUIScrollyLabel.h"

@interface TweaksViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    AUIPopupWindow *popupWindow;
    
    NSArray *sourcesArray;
    NSMutableArray *json_data;
}


@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

