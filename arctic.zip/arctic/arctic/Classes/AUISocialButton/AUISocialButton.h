//
//  AUISocialButton.h
//  arctic
//
//  Created by Antique_Dev on 29/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUISocialButton : UIButton
@property (nonatomic) UIRectCorner corners;
@end
