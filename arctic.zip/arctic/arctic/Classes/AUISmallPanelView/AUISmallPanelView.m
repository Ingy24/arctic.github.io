//
//  AUIAppPageView.m
//  arctic
//
//  Created by Antique_Dev on 28/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "AUISmallPanelView.h"

@implementation AUISmallPanelView
-(void) layoutSubviews {
    [super layoutSubviews];
    [self setBackgroundColor:[UIColor whiteColor]];
    [self.layer setMasksToBounds:NO];
    [self.layer setCornerRadius:26];
    [self.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.layer setBorderWidth:0.8];
    [self.layer setShadowColor:[UIColor blackColor].CGColor];
    [self.layer setShadowOffset:CGSizeZero];
    [self.layer setShadowRadius:1];
    [self.layer setShadowOpacity:0.8];
    
    
    _installButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_installButton addTarget:self action:@selector(install:) forControlEvents:UIControlEventTouchUpInside];
    [_installButton setTitleColor:[UIColor colorWithRed:0/255.0f green:122/255.0f blue:255/255.0f alpha:1] forState:UIControlStateNormal];
    [_installButton.titleLabel setFont:[UIFont boldSystemFontOfSize:12]];
    [_installButton setTitle:@"GET" forState:UIControlStateNormal];
    [_installButton setFrame:CGRectMake(96, 68, 48, 20)];
    [_installButton setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.1]];
    [_installButton setClipsToBounds:YES];
    [_installButton.layer setCornerRadius:10];
    [self addSubview:_installButton];
}


-(void) install:(UIButton *)sender {
    
}
@end
