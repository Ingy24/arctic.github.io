//
//  AUISocialButton.m
//  arctic
//
//  Created by Antique_Dev on 29/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "AUISocialButton.h"

@implementation AUISocialButton
-(void) layoutSubviews {
    [super layoutSubviews];
    CAShapeLayer *layer = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:self.corners cornerRadii:CGSizeMake(15, 15)];
    [layer setPath:path.CGPath];
    [self.layer setMask:layer];
}
@end
