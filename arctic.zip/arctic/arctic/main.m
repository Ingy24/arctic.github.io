//
//  main.m
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
