//
//  AUILargePanelView.m
//  arctic
//
//  Created by Antique_Dev on 29/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "AUILargePanelView.h"

@implementation AUILargePanelView
-(void) layoutSubviews {
    [super layoutSubviews];
    [self setBackgroundColor:[UIColor whiteColor]];
    [self.layer setMasksToBounds:NO];
    [self.layer setCornerRadius:30];
    [self.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.layer setBorderWidth:0.8];
    [self.layer setShadowColor:[UIColor blackColor].CGColor];
    [self.layer setShadowOffset:CGSizeZero];
    [self.layer setShadowRadius:1];
    [self.layer setShadowOpacity:0.8];
}
@end
