//
//  SourcesViewController.m
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "TweaksViewController.h"
#import "HomeViewController.h"



@interface TweaksViewController () {
    
}

@property (nonatomic, retain) NSIndexPath *index;
@end

@implementation TweaksViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [[self view] setBackgroundColor:[UIColor whiteColor]];
    CGFloat width = self.view.bounds.size.width;
    CGFloat height = self.view.bounds.size.height;
    
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 90)];
    [headerView setBackgroundColor:[UIColor whiteColor]];
    [[headerView layer] setShadowColor:[UIColor lightGrayColor].CGColor];
    [[headerView layer] setShadowRadius:0.5];
    [[headerView layer] setShadowOpacity:0.5];
    [[headerView layer] setShadowOffset:CGSizeMake(0, 1)];
    [[self view] addSubview:headerView];
    
    UILabel *sourcesLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, headerView.bounds.size.height - 48, headerView.bounds.size.width - 16, 44)];
    [sourcesLabel setText:@"Tweaks"];
    [sourcesLabel setFont:[UIFont boldSystemFontOfSize:38]];
    [headerView addSubview:sourcesLabel];
    
    
    
    // https://github.com/antiquebeta/arctic.github.io/blob/master/data/tweaks.json
    
    sourcesArray = [NSArray arrayWithContentsOfURL:[NSURL URLWithString:@"https://raw.githubusercontent.com/antiquebeta/arctic.github.io/master/data/tweaks.plist"]];
    
    [_tableView setDelegate:self];
    [_tableView setDataSource:self];
    [_tableView setSeparatorInset:UIEdgeInsetsMake(0, 68, 0, 15)];
}


-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [sourcesArray count];
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    _index = indexPath;
    
    static NSString *cellID = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    AUIScrollyLabel *nameLabel = (AUIScrollyLabel *)[cell viewWithTag:20];
    [nameLabel setFont:[UIFont boldSystemFontOfSize:18]];
    nameLabel.text = [[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"name"];
    
    AUIScrollyLabel *descriptionLabel = (AUIScrollyLabel *)[cell viewWithTag:30];
    [descriptionLabel setFont:[UIFont systemFontOfSize:10]];
    descriptionLabel.text = [[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"description"];
    
    AUIScrollyLabel *developerLabel = (AUIScrollyLabel *)[cell viewWithTag:35];
    [developerLabel setFont:[UIFont systemFontOfSize:8]];
    [developerLabel setTextColor:[UIColor lightGrayColor]];
    developerLabel.text = [NSString stringWithFormat:@"by %@", [[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"developer"]];
    
    UILabel *priceLabel = (UILabel *)[cell viewWithTag:60];
    [priceLabel setFont:[UIFont systemFontOfSize:10]];
    
    if([[[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"price"] isEqualToString:@"Free"]) {
    priceLabel.text = [NSString stringWithFormat:@"%@", [[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"price"]];
    } else {
    priceLabel.text = [NSString stringWithFormat:@"$%@", [[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"price"]];
    }
    
    
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:10];
    [imageView setClipsToBounds:YES];
    [imageView.layer setCornerRadius:10];
    [imageView setImage:[UIImage imageNamed:@"tweak_default"]];
    
    UIButton *getButton = (UIButton *)[cell viewWithTag:50];
    [getButton setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.072]];
    [getButton.layer setCornerRadius:10];
    [getButton.layer setBorderColor:[UIColor darkGrayColor].CGColor];
    [getButton.layer setBorderWidth:1];
    return cell;
}


-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Info" message:[NSString stringWithFormat:@"Arctic has not included this feature yet, would you download %@?", [[sourcesArray objectAtIndex:indexPath.row] valueForKey:@"name"]] preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Download" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    
    [alert addAction:ok];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
