//
//  ChangesViewController.m
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "NewViewController.h"

@interface NewViewController ()
@end

@implementation NewViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [[self view] setBackgroundColor:[UIColor whiteColor]];
    CGFloat width = self.view.bounds.size.width;
    CGFloat height = self.view.bounds.size.height;
    
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 90)];
    [headerView setBackgroundColor:[UIColor whiteColor]];
    [[headerView layer] setShadowColor:[UIColor lightGrayColor].CGColor];
    [[headerView layer] setShadowRadius:0.5];
    [[headerView layer] setShadowOpacity:0.5];
    [[headerView layer] setShadowOffset:CGSizeMake(0, 2.5)];
    [[self view] addSubview:headerView];
    
    UILabel *newLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, headerView.bounds.size.height - 48, headerView.bounds.size.width - 16, 44)];
    [newLabel setText:@"New Releases"];
    [newLabel setFont:[UIFont boldSystemFontOfSize:38]];
    [headerView addSubview:newLabel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
