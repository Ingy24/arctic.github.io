//
//  AUIPopupWindow.m
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "AUIPopupWindow.h"

@implementation AUIPopupWindow
-(void) layoutSubviews {
    [super layoutSubviews];
    [self setHidden:YES];
    [self setAlpha:0];
    
    UIVisualEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    [visualEffectView setFrame:self.bounds];
    [self addSubview:visualEffectView];
    
    
    /*
    _popupView = [[AUIPopupView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width - 64, 196)];
    [_popupView setCenter:self.center];
    [self addSubview:_popupView];
    */
    
    
    UITapGestureRecognizer *closePopup = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closePopup:)];
    [self addGestureRecognizer:closePopup];
}

-(void) closePopup:(UITapGestureRecognizer *)sender {
    [UIView animateWithDuration:0.5 animations:^{
    [self setAlpha:0];
    }];
}
@end
