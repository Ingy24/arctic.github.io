//
//  AUIAppPageView.h
//  arctic
//
//  Created by Antique_Dev on 28/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUISmallPanelView : UIView

@property (nonatomic, strong) UIButton *installButton;
@end
