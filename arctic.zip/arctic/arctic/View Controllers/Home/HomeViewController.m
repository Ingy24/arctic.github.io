//
//  HomeViewController.m
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "HomeViewController.h"
#import "TweaksViewController.h"

@interface HomeViewController () {
    AUIPopupWindow *aboutPopup;
}
@end

@implementation HomeViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [[self view] setBackgroundColor:[UIColor whiteColor]];
    CGFloat width = self.view.bounds.size.width;
    CGFloat height = self.view.bounds.size.height;
    
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 90)];
    [headerView setBackgroundColor:[UIColor whiteColor]];
    [[headerView layer] setShadowColor:[UIColor lightGrayColor].CGColor];
    [[headerView layer] setShadowRadius:0.5];
    [[headerView layer] setShadowOpacity:0.5];
    [[headerView layer] setShadowOffset:CGSizeMake(12, 2.5)];
    [[self view] addSubview:headerView];
    
    UILabel *homeLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, headerView.bounds.size.height - 48, headerView.bounds.size.width / 2, 44)];
    [homeLabel setText:@"Home"];
    [homeLabel setFont:[UIFont boldSystemFontOfSize:38]];
    [headerView addSubview:homeLabel];
    
    UIButton *aboutButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
    [aboutButton setImageEdgeInsets:UIEdgeInsetsMake(4, 4, 4, 4)];
    [aboutButton setFrame:CGRectMake(headerView.bounds.size.width - 26, headerView.bounds.size.height - 26, 26, 26)];
    [aboutButton addTarget:self action:@selector(popupAbout:) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:aboutButton];
    
    
    aboutPopup = [[AUIPopupWindow alloc] initWithFrame:self.view.bounds];
    [aboutPopup setHidden:YES];
    [aboutPopup setAlpha:0];
    [[UIApplication sharedApplication].keyWindow addSubview:aboutPopup];
}



-(void) popupAbout:(UIButton *)sender {
    [UIView animateWithDuration:0.5 animations:^{
        [aboutPopup setHidden:NO];
        [aboutPopup setAlpha:1];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
