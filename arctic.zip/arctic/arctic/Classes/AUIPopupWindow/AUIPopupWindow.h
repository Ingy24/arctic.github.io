//
//  AUIPopupWindow.h
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "AUIPopupView.h"

@interface AUIPopupWindow : UIWindow {
    UIButton *closeButton;
}

@property (nonatomic, retain) AUIPopupView *popupView;
@end
