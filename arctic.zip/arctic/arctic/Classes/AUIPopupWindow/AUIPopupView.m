//
//  AUIPopupWindow.m
//  arctic
//
//  Created by Antique_Dev on 24/11/17.
//  Copyright © 2017 Antique_Dev. All rights reserved.
//

#import "AUIPopupView.h"

@implementation AUIPopupView
-(void) layoutSubviews {
    [super layoutSubviews];
    [[self layer] setMasksToBounds:NO];
    [[self layer] setCornerRadius:13.5];
    [self setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:0.68]];
}
@end
